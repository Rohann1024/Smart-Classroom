//JavaScript for form submission
document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent the form from submitting normally
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    if (name && email) {
             document.getElementById('success-message').style.display = 'block';
             document.getElementById('signup-form').reset(); // Reset the form
         } else {
            alert('Please fill in both fields.');
       }
    });
    
    
    