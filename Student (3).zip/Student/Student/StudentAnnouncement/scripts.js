document.addEventListener('DOMContentLoaded', () => {
    const announcements = [
      { title: 'Exam Schedule Released', content: 'The exam schedule has been released. Please check the portal for details.' },
      { title: 'Sports Day Registration', content: 'Sports Day will be held on Sept 15. Register by Sept 10 to participate.' },
      { title: 'New Library Hours', content: 'The library will now be open from 8:00 AM to 10:00 PM, Monday to Friday.' }
    ];
  
    const announcementList = document.getElementById('announcement-list');
    
    announcements.forEach(announcement => {
      const announcementDiv = document.createElement('div');
      announcementDiv.className = 'announcement';
      announcementDiv.innerHTML = `
        <h3>${announcement.title}</h3>
        <p>${announcement.content}</p>
      `;
      announcementList.appendChild(announcementDiv);
    });
  });
  