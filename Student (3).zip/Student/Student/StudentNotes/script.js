

// JavaScript to handle note viewing in a modal
document.querySelectorAll('.note-item').forEach(note => {
    note.addEventListener('click', function() {
        const noteTitle = this.querySelector('strong').textContent;
        const noteContent = this.getAttribute('data-content');

        // Set the modal content
        document.getElementById('modal-note-title').textContent = noteTitle;
        document.getElementById('modal-note-content').textContent = noteContent;

        // Show the modal
        document.getElementById('note-modal').style.display = 'block';
    });
});

// Close the modal when the close button is clicked
document.querySelector('.close-button').addEventListener('click', function() {
    document.getElementById('note-modal').style.display = 'none';
});

// Close the modal when clicking outside the modal content
window.addEventListener('click', function(event) {
    const modal = document.getElementById('note-modal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});


